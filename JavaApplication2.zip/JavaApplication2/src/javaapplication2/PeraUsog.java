package javaapplication2;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


import java.util.ArrayList;
import java.util.Scanner;


/**
 *
 * @author Acer
 */
public class PeraUsog {
    public static void main(String[] args) {
        Scanner s= new Scanner(System.in);
        ArrayList<Integer> oldbalance = new ArrayList<>();
           ArrayList<Integer> newbalance=oldbalance;
      
     while(true){
             
        System.out.println("1.Deposit");
        System.out.println("2.Withdraw");
        System.out.println("3.Check Balance");
        System.out.println("Choose a number: ");
        int menu=s.nextInt();
        
         
            
       
        if(menu==1){
            System.out.println("enter number you want to deposit: ");
             int deposit = s.nextInt();
            System.out.println("your old balance: "+oldbalance);
             newbalance.add(deposit);
            
            System.out.println("you deposited "+ deposit+" in your account");
            System.out.println("your new balance:"+newbalance);
            System.out.println("");
            System.out.println("do you want another transaction? ");
            System.out.println("1=yes 2=no");
            menu=s.nextInt();
            if(menu==2){
                break;
            }
            
        }else if(menu==2){
            System.out.println("enter number:");
            int withdraw=s.nextInt();
            
            System.out.println("your old balance: "+oldbalance);
          oldbalance.removeIf(old->old==withdraw);
            System.out.println("you withdraw "+withdraw+" in your account");
                System.out.println("your new balance:"+newbalance); 
            System.out.println(""); 
            System.out.println("do you want another transaction? ");
            System.out.println("1=yes 2=no");
            menu=s.nextInt();
            if(menu==2){
                break;  
        }
            
            
    }else if(menu==3){
     
            System.out.println("");
     System.out.println("your balance in your account:"+ newbalance);

             System.out.println("do you want another transaction? ");
            System.out.println("1=yes 2=no");
            System.out.println("");
            menu=s.nextInt();
            if(menu==2){
                break;
            }

    }else {System.out.println("the number you entered is invalid");
            System.out.println("");
            System.out.println("do you want to re-enter");
            System.out.println("1=yes  2=no");
            menu=s.nextInt();
            if(menu==2){
                System.out.println("thank you come again!!");
                break;
            }
    }
         
     }   
     
     System.out.println("thank you come again!!");
                
          
    }
    
    
}
